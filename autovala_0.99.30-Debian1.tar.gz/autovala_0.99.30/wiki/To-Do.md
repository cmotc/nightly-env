While Autovala is fully usable, there are still a lot of things that I want to add to it, and I will need help.

 * Support localization of desktop files
