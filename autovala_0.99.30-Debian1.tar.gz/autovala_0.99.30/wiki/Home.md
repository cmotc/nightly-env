# AUTOVALA

Autovala is a program and a library designed to help in the creation of projects with Vala and CMake.

The idea is quite simple: CMake is very powerful, but writting the CMakeLists files is boring and repetitive. Why not let the computer create them, by guessing what to do with each file? And if, at the end, there are mistakes, let the user fix them in an easy way, and generate the final CMakeLists files.

[You can read the documentation by clicking here](wiki/index.html)