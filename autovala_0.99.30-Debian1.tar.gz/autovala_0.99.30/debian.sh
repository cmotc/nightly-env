#! /bin/sh
DEBFOLDERNAME="autovala_0.99.30"
cd autovala
make clean
git pull upstream master
git push origin master
rm "../$DEBFOLDERNAME.orig.tar.xz"
rm -rf "../$DEBFOLDERNAME"
tar cf - ./ | xz -zf - > "../$DEBFOLDERNAME.orig.tar.xz"
cp -R ./ "../$DEBFOLDERNAME"
cd "../$DEBFOLDERNAME"
dpkg-source --commit
debuild -d >> ../log

